
<link rel="stylesheet" href=./style/css/bootstrap.min.css>
<script src="./style/js/bootstrap.min.js"></script>
<?php
$db='eshop';
$link = mysqli_connect("127.0.0.1", "root", "", "$db");

?>


<form method="post" enctype="multipart/form-data" class="form-group">
product name: <input type="text" name="productname" autocomplete="off" class="form-control" value="<?PHP if(isset($_POST['productname'])) echo htmlspecialchars($_POST['productname']); ?>"><br/>

product code: <input type="text" name="productcode" autocomplete="off" class="form-control" value="<?PHP if(isset($_POST['productcode'])) echo htmlspecialchars($_POST['productcode']); ?>"><br/>
price: <input type="text" name="price" autocomplete="off" class="form-control" value="<?PHP if(isset($_POST['price'])) echo htmlspecialchars($_POST['price']); ?>"><br/>
Description: <input type="text" name="description"  autocomplete="off" class="form-control" value="<?PHP if(isset($_POST['description'])) echo htmlspecialchars($_POST['description']); ?>"> <br/>
product photo:<input type="file" class="btn btn-primary" for="my-file-selector" name="user_image" accept="image/*">
<p>
product category
<select name="category" class="btn btn-default dropdown-toggle" role="menu">
  <option value="">Select...</option>
  <option value="womens_fashion">Womens fashion wears</option>
  <option value="mens_fashion">mens fashion wears</option>
  <option value="watches">watches</option>
  <option value="glasses">Glasses</option>
  <option value="mobiles">Mobile phones</option>
  <option value="computers">computers and laptops</option>
  <option value="sports">sports</option>
  <option value="shoes">shoes</option>
  <option value="musics">musics</option>
  <option value="others">others</option>
  
</select>
</p>

<input type="submit" name="submit" value="submit" class="btn btn-success">
</form>

<?php

if(isset($_POST['submit']))
{ 
	$productname=$_POST['productname'];
	$productcode=$_POST['productcode'];
	$productprice=$_POST['price'];
	$description=$_POST['description'];
	$category=$_POST['category'];

  
  


if($productname==''||$productcode==''||$productprice==''||$description==''||$category=='')
{
	echo "please fill all the forms";

}
else 
{


$file_name=$_FILES['user_image']['name'];
  $file_type=$_FILES['user_image']['type'];
  $file_size=$_FILES['user_image']['size'];
  $file_tmp_name=$_FILES['user_image']['tmp_name'];
  $destination = "photo/".$file_name;

if($file_name)
  {
  
    move_uploaded_file($file_tmp_name, $destination);
    
 }

	$query="INSERT INTO products(product_type,product_name,product_price,product_code,product_photo,product_description) VALUES('$category','$productname','$productprice','$productcode','$destination','$description')";
 if(mysqli_query($link,$query))
{
  //echo $category;
  //$last_id=mysqli_insert_id($link);
  //$queryinside=mysqli_query($link,"INSERT INTO categories(product_id) VALUES ('$last_id') WHERE product_type='$category' ");
  //if(!$queryinside)
  //{
    //echo mysqli_error($link);
  //}
  }
else
{
	echo mysqli_error($link);
}
}
}

?>