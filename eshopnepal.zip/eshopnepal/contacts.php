<link rel="stylesheet" href=./style/css/bootstrap.min.css>
<script src="./style/js/bootstrap.min.js"></script>
<link rel="stylesheet" href=./style/style.css>


<?php
include('header.php');

?>

<?php
$db='eshop';
$link = mysqli_connect("127.0.0.1", "root", "", "$db");
?>

<div class="ku">
<img  src="./headerphotos/kathmandu university.png" width="100%" height="400px">
</div>
<div class="contactdetails">
<h3>Email</h3>
eshopNepal@gmail.com<br/><br/>
<h3>Telephone</h3>
9860240417<br/><br/>
<h3>Address</h3>
Kathmandu University<br/>
KU Road, 28 Kilo <br/>
Kavre, Nepal

</div>


<div class="contactadmin">




<form method="post" class="form-group">
Full Name: <input type="text" name="fullname" autocomplete="off" class="form-control" id="fname" value="<?PHP if(isset($_POST['fullname'])) echo htmlspecialchars($_POST['fullname']); ?>"><br/>

Email: <input type="email" name="emailid" autocomplete="off" class="form-control" id="cemail" value="<?PHP if(isset($_POST['emailid'])) echo htmlspecialchars($_POST['emailid']); ?>"><br/>


Message:  <input type="text" name="message" autocomplete="off" class="form-control" id="message" value="<?PHP if(isset($_POST['message'])) echo htmlspecialchars($_POST['message']); ?>"><br/>


<input type="submit" name="submit" value="send" class="btn btn-success">

</form>


</div>

<?php
if(isset($_POST['submit']))
{
	$fullname=$_POST['fullname'];
	$email =$_POST['emailid'];
	$message=$_POST['message'];
	if($fullname==''||$email==''||$message=='')
	{
		echo "please complete all the forms ";
	}
	else
	{
		$query="INSERT INTO user_contacts(username,email_id,message) VALUES ('$fullname','$email','$message')";
		$query1=mysqli_query($link,$query);
		if($query1)
		{
			$user_id=mysqli_insert_id($link);
			header("location:thankscontacting.php?sendername=$user_id ");
		}
	}
}



?>