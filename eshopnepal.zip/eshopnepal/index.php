<link rel="stylesheet" href=./style/css/bootstrap.min.css>
<script src="./style/js/bootstrap.min.js"></script>
<link rel="stylesheet" href=./style/style.css>


<?php
include('header.php');

?>










<nav>
<h4> categories </h4><br/>
<a href=categoriesdisplay.php?category=mens_fashion>mens fashion</a><br/>
<a href=categoriesdisplay.php?category=womens_fashion>womens fashion</a><br/>
<a href=categoriesdisplay.php?category=watches>watches</a><br/>
<a href=categoriesdisplay.php?category=glasses>Glasses</a><br/>
<a href=categoriesdisplay.php?category=computers>computers and laptops</a><br/>
<a href=categoriesdisplay.php?category=sports>sports</a><br/>
<a href=categoriesdisplay.php?category=shoes>shoes</a><br/>
<a href=categoriesdisplay.php?category=musics>musics</a><br/>
<a href=categoriesdisplay.php?category=clothes>clothes</a><br/>
<a href=categoriesdisplay.php?category=others>others</a><br/>





</nav>
<div class="slider_image">






<style>
.mySlides {display:none;
padding-top: 80px;}
</style>


<class="w3-center">

<div class="w3-content w3-section" >
  <img class="mySlides" src="./headerphotos/4.jpg" width=90% height=350px>
  <img class="mySlides" src="./headerphotos/5.png" width=90% height=350px>
  <img class="mySlides" src="./headerphotos/6.jpg" width=90% height=350px>
  
</div>

<script>
var myIndex = 0;
carousel();

function carousel() {
    var i;
    var x = document.getElementsByClassName("mySlides");
    for (i = 0; i < x.length; i++) {
       x[i].style.display = "none";  
    }
    myIndex++;
    if (myIndex > x.length) {myIndex = 1}    
    x[myIndex-1].style.display = "block";  
    setTimeout(carousel, 5000); // Change image every 2 seconds
}
</script>




</div>
<div class="display_products">
<?php
$db='eshop';
$link = mysqli_connect("127.0.0.1", "root", "", "$db");
?>

<?php
$query= "SELECT * FROM products LIMIT 12";
$result=mysqli_query($link,$query);
while($row=mysqli_fetch_array($result,MYSQLI_ASSOC))
      {
           
          $producttype  =$row['product_type'];
          $productname=$row['product_name'];
          $productprice=$row['product_price'];
          $productcode=$row['product_code'];
          $productphoto=$row['product_photo'];
          $productdesc=$row['product_description'];
           $productid=$row['id'];    
               ?>
              <div class="product_items"><li><a href="viewproducts.php?page_id=<?php echo $productid ?>">
              <br/> <img src=<?php echo $productphoto ?> height='200' width='200'/> <br/>
              
               <?php
               //echo "id" ."$productid";
                //echo "<br/>";                      
               //echo "type " ."$producttype";
               //echo "<br/>";
                echo $productname;
                echo "<br/>";
                echo "RS. "."$productprice";
                

               
                ?>
                </a></li></div>
                <?php
            }
?>
</div>
</div>
</div>

<footer> </footer>