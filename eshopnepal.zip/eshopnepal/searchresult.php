<link rel="stylesheet" href=./style/css/bootstrap.min.css>
<script src="./style/js/bootstrap.min.js"></script>
<link rel="stylesheet" href=./style/style.css>

<?php
include('header.php');

?>


<?php

$db='eshop';
$link = mysqli_connect("127.0.0.1", "root", "", "$db");
?>



<nav>
<h4> categories </h4><br/>
<a href=categoriesdisplay.php?category=mens_fashion>mens fashion</a><br/>
<a href=categoriesdisplay.php?category=womens_fashion>womens fashion</a><br/>
<a href=categoriesdisplay.php?category=watches>watches</a><br/>
<a href=categoriesdisplay.php?category=glasses>Glasses</a><br/>
<a href=categoriesdisplay.php?category=computers>computers and laptops</a><br/>
<a href=categoriesdisplay.php?category=sports>sports</a><br/>
<a href=categoriesdisplay.php?category=shoes>shoes</a><br/>
<a href=categoriesdisplay.php?category=musics>musics</a><br/>
<a href=categoriesdisplay.php?category=clothes>clothes</a><br/>
<a href=categoriesdisplay.php?category=others>others</a><br/>





</nav>



<div class="display_products">
<?php
  if(isset($_POST['search'])){
  {
  if(preg_match("/^[  a-zA-Z]+/", $_POST['asd'])){
  $name=$_POST['asd'];


$sql="SELECT * FROM products WHERE product_name LIKE '% ". $name ."%' OR product_type LIKE '%" . $name ."%' OR product_code LIKE '%".$name."'";

  $result=mysqli_query($link,$sql);

  while($row=mysqli_fetch_array($result,MYSQLI_ASSOC)){
          
           $producttype  =$row['product_type'];
          $productname=$row['product_name'];
          $productprice=$row['product_price'];
          $productcode=$row['product_code'];
          $productphoto=$row['product_photo'];
          $productdesc=$row['product_description'];
           $productid=$row['id'];    
         
  ?>
  <div class="product_items"><li><a href="viewproducts.php?page_id=<?php echo $productid ?>">
              <br/> <img src=<?php echo $productphoto ?> height='200' width='200'/> <br/>
              
  <?php
   echo $productname;
                echo "<br/>";
                echo "RS. "."$productprice";
               ?>
               </a></li></div>
               <?php 
  }
  }
  else{
  echo  "<p>Please enter a search query</p>";
  }
  }
  }
?>

</div>
