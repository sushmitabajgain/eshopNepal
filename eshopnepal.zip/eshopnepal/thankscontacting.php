<link rel="stylesheet" href=./style/css/bootstrap.min.css>
<script src="./style/js/bootstrap.min.js"></script>
<link rel="stylesheet" href=./style/style.css>


<?php
include('header.php');

?>

<?php
$db='eshop';
$link = mysqli_connect("127.0.0.1", "root", "", "$db");
?>


<?php
if(isset($_GET['sendername']))
{
	$sender= $_GET['sendername'];
}

?>

<?php

$query="SELECT * FROM user_contacts WHERE id='$sender'";
$query1=mysqli_query($link,$query);
$row=mysqli_fetch_array($query1,MYSQLI_ASSOC);
$sendername=$row['username'];

?>

<div class="replytosender">

<h3> Thankyou <?php  echo $sendername; echo ","; ?> </h3>  for contacting us. We will try to get you as soon as possible. Have a good day 

</div>