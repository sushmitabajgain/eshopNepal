<link rel="stylesheet" href=./style/css/bootstrap.min.css>
<script src="./style/js/bootstrap.min.js"></script>
<link rel="stylesheet" href=./style/style.css>

<?php
include('header.php');
?>


<?php
$db='eshop';
$link = mysqli_connect("127.0.0.1", "root", "", "$db");
?>


<?php
if(isset($_GET['page_id']))
{
	$id = $_GET['page_id'];

}

$query="SELECT * FROM products WHERE id=$id";
$result=mysqli_query($link,$query);
if(!$result)
{
	echo "no orders";
}
else
{
	 $row=mysqli_fetch_array($result,MYSQLI_ASSOC);
          $producttype  =$row['product_type'];
          $productname=$row['product_name'];
          $productprice=$row['product_price'];
          $productcode=$row['product_code'];
          $productphoto=$row['product_photo'];
          $productdesc=$row['product_description'];
           $productid=$row['id'];    
               ?>
              <div class="diplay_layout">
              <br/> <img src=<?php echo $productphoto ?> height='400' width='400' style="margin-left: 100px;padding-top: 40px;"/>
              </div>
              <div class="order_lays">
               <?php
               
                echo "<h4><p class=text-primary> NAME </h4>";
                echo $productname;
                echo "<br/>";
                echo "<br/>";
                echo "<h4><p class=text-primary> PRICE </h4>";
                echo $productprice;
                echo "<br/>";
                echo "<br/>";
                echo "<h4><p class=text-primary> PRODUCT CODE </h4>";
                echo $productcode;
                echo "<br/>";
                echo "<br/>";
                echo "<h4><p class=text-primary> DESCRIPTION </h4>";
                echo $productdesc;

                ?>
</br></br>
            
                </div>
<div class="orderform">
<form method="post">
  <div class="form-group">
    <label for="name">Full Name</label>
    <input type="text" class="form-control" id="cust_name" name="cust_name" autocomplete="off" value="<?PHP if(isset($_POST['cust_name'])) echo htmlspecialchars($_POST['cust_name']); ?>">
  </div>

  <div class="form-group">
    <label for="email">Email address:</label>
    <input type="email" class="form-control" id="cust_email" autocomplete="off" name="cust_email" value="<?PHP if(isset($_POST['cust_email'])) echo htmlspecialchars($_POST['cust_email']); ?>">
  </div>


  <div class="form-group">
    <label for="phone number">Phone number</label>
    <input type="text" class="form-control" id="cust_phone" autocomplete="off" name="cust_phone" value="<?PHP if(isset($_POST['cust_phone'])) echo htmlspecialchars($_POST['cust_phone']); ?>">
  </div>

  <div class="form-group">
    <label for="district">District</label>
    <input type="text" class="form-control" id="cust_district" autocomplete="off" name="cust_district" value="<?PHP if(isset($_POST['cust_district'])) echo htmlspecialchars($_POST['cust_district']); ?>">
  </div>


  <div class="form-group">
    <label for="Address">Address</label>
    <input type="text" class="form-control" id="cust_address" name="cust_address" autocomplete="off" value="<?PHP if(isset($_POST['cust_address'])) echo htmlspecialchars($_POST['cust_address']); ?>">
  </div>

  <button type="submit" class="btn btn-default" name="place_order">order</button><button type="submit" class="btn btn-default" name="cancel_order" style="margin-left: 10px">cancel</button>
</form>
</div>
                <?php

}

?>
 
<?php
if(isset($_POST['cancel_order']))
{
  header('location:index.php');
}

?>

<?php

if(isset($_POST['place_order']))
{
	$customername=$_POST['cust_name'];
	$customer_email=$_POST['cust_email'];
	$customer_phone=$_POST['cust_phone'];
	$customer_district=$_POST['cust_district'];
	$customer_address=$_POST['cust_address'];
	$date=date('Y-m-d ');
	$time=date('H:i:s');

	if($customername==''||$customer_email==''||$customer_phone==''||$customer_district==''||$customer_address=='')
	{
		echo "please fill all the forms correctly";
		exit();
	}
	else
	{
       $query="INSERT INTO customer_order(product_id,customer_name,customer_email,customer_phone,customer_district,customer_address,order_date,order_time,product_price) VALUES('$id','$customername','$customer_email','$customer_phone','$customer_district','$customer_address','$date','$time','$productprice')";
       $query1=mysqli_query($link,$query);
        $last_id = mysqli_insert_id($link);
       if($query1)
       {
       	echo $last_id;
       	header("location:ordersuccess.php?cust_order=$last_id ");
       }
	}
}


?>






