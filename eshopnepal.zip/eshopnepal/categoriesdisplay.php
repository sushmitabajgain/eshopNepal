
<link rel="stylesheet" href=./style/css/bootstrap.min.css>
<script src="./style/js/bootstrap.min.js"></script>
<link rel="stylesheet" href=./style/style.css>
<?php
include('header.php');

?>
<nav>
<h4> categories </h4><br/>
<a href=categoriesdisplay.php?category=mens_fashion>mens fashion</a><br/>
<a href=categoriesdisplay.php?category=womens_fashion>womens fashion</a><br/>
<a href=categoriesdisplay.php?category=watches>watches</a><br/>
<a href=categoriesdisplay.php?category=glasses>Glasses</a><br/>
<a href=categoriesdisplay.php?category=computers>computers and laptops</a><br/>
<a href=categoriesdisplay.php?category=sports>sports</a><br/>
<a href=categoriesdisplay.php?category=shoes>shoes</a><br/>
<a href=categoriesdisplay.php?category=musics>musics</a><br/>
<a href=categoriesdisplay.php?category=clothes>clothes</a><br/>
<a href=categoriesdisplay.php?category=others>others</a><br/>





</nav>

<div class="display_products">
<?php
$db='eshop';
$link = mysqli_connect("127.0.0.1", "root", "", "$db");
?>

<?php
if(isset($_GET['category']))
{
	$category=$_GET['category'];
	
}

?>

<?php

$query="SELECT * FROM products WHERE product_type='$category'";
$query1=MYSQLI_QUERY($link,$query);
while($row=mysqli_fetch_array($query1,MYSQLI_ASSOC))
{
			$producttype  =$row['product_type'];
          $productname=$row['product_name'];
          $productprice=$row['product_price'];
          $productcode=$row['product_code'];
          $productphoto=$row['product_photo'];
          $productdesc=$row['product_description'];
           $productid=$row['id'];
           ?>
           <div class="product_items"><li><a href="viewproducts.php?page_id=<?php echo $productid ?>">
              <br/> <img src=<?php echo $productphoto ?> height='200' width='200'/> <br/>
              
               <?php
               //echo "id" ."$productid";
                //echo "<br/>";                      
               //echo "type " ."$producttype";
               //echo "<br/>";
                echo $productname;
                echo "<br/>";
                echo "RS. "."$productprice";
                

               
               ?>
                </a></li></div>
                <?php
}


?>

</div>