
<link rel="stylesheet" href=./style/css/bootstrap.min.css>
<script src="./style/js/bootstrap.min.js"></script>
<link rel="stylesheet" href=./style/style.css>


<?php
$db='eshop';
$link = mysqli_connect("127.0.0.1", "root", "", "$db");
?>
<?php
include('header.php');

?>






<nav>
<h4> categories </h4><br/>
<a href=categoriesdisplay.php?category=mens_fashion>mens fashion</a><br/>
<a href=categoriesdisplay.php?category=womens_fashion>womens fashion</a><br/>
<a href=categoriesdisplay.php?category=watches>watches</a><br/>
<a href=categoriesdisplay.php?category=glasses>Glasses</a><br/>
<a href=categoriesdisplay.php?category=computers>computers and laptops</a><br/>
<a href=categoriesdisplay.php?category=sports>sports</a><br/>
<a href=categoriesdisplay.php?category=shoes>shoes</a><br/>
<a href=categoriesdisplay.php?category=musics>musics</a><br/>
<a href=categoriesdisplay.php?category=clothes>clothes</a><br/>
<a href=categoriesdisplay.php?category=others>others</a><br/>





</nav>


<div class="display_products">


<?php
if(isset($_GET['page_id']))
{
	$id = $_GET['page_id'];

}

$query="SELECT * FROM products WHERE id=$id";
$result=mysqli_query($link,$query);
if(!$result)
{
	echo mysql_error($link);
}
else
{
	 $row=mysqli_fetch_array($result,MYSQLI_ASSOC);
          $producttype  =$row['product_type'];
          $productname=$row['product_name'];
          $productprice=$row['product_price'];
          $productcode=$row['product_code'];
          $productphoto=$row['product_photo'];
          $productdesc=$row['product_description'];
           $productid=$row['id'];    
               ?>
              <div class="diplay_layout">
              <br/> <img src=<?php echo $productphoto ?> height='500' width='400'/>
              </div>
              <div class="display_lays">
               <?php
               
                echo "<h4><p class=text-primary> NAME </h4>";
                echo $productname;
                echo "<br/>";
                echo "<br/>";
                echo "<h4><p class=text-primary> PRICE </h4>";
                echo "RS. ";
                echo $productprice;
                echo "<br/>";
                echo "<br/>";
                echo "<h4><p class=text-primary> PRODUCT CODE </h4>";
                echo $productcode;
                echo "<br/>";
                echo "<br/>";
                echo "<h4><p class=text-primary> DESCRIPTION </h4>";
                echo $productdesc;

                ?>
</br></br>
            <a href="orderdetails.php?page_id=<?php echo $productid ?>"> <input type="submit" name="order" value="order now" class= "btn btn-info"></a>
                </div>
                <?php

}

?>




























<?php
$query2 = "SELECT product_type FROM products WHERE id=$id";
$query3=mysqli_query($link,$query2);
if($row1=mysqli_fetch_array($query3,MYSQLI_ASSOC))
{
$product = $row1['product_type'];
}
?>
<?php
$query4 = "SELECT * FROM products WHERE product_type= '$product' AND id !='$id' ";
$query5 =mysqli_query($link,$query4);
$query6= "SELECT * FROM products WHERE product_type='$product'";
$query7=mysqli_query($link,$query6);
if(mysqli_num_rows($query7)>1)
{
  ?>
<h2><p class="hidden">similar products</p></h2>
<?php
}
while($query6=mysqli_fetch_array($query5,MYSQLI_ASSOC))
{
          $producttype  =$query6['product_type'];
          $productname=$query6['product_name'];
          $productprice=$query6['product_price'];
          $productcode=$query6['product_code'];
          $productphoto=$query6['product_photo'];
          $productdesc=$query6['product_description'];
           $productid=$query6['id'];    
         ?>
         
         <div class="product_items"><li><a href="viewproducts.php?page_id=<?php echo $productid ?>">
           <br/> <img src=<?php echo $productphoto ?> height='200' width='200'/> <br/>
           <?php


                            
                echo $productname;
                echo "<br/>";
                echo "RS." ."$productprice";
                echo "<br/>";
                ?>
                </a></li></div>
                <?php

}

?>

</div>