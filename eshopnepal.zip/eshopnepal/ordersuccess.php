<link rel="stylesheet" href=./style/css/bootstrap.min.css>
<script src="./style/js/bootstrap.min.js"></script>
<link rel="stylesheet" href=./style/style.css>


<?php
include('header.php');
?>
<?php
$db='eshop';
$link = mysqli_connect("127.0.0.1", "root", "", "$db");
?>


<?php
if(isset($_GET['cust_order']))
{
	$order_id=$_GET['cust_order'];
}

?>
<div class="ordersubmit">
<?php
$query="SELECT * FROM customer_order WHERE id='$order_id'";
$query1=mysqli_query($link,$query);
if(!$query1)
{
	echo "error";
}
else{
	$row=mysqli_fetch_array($query1,MYSQLI_ASSOC);
	$productid = $row['product_id'];
	$customername = $row['customer_name'];
	$customeremail = $row['customer_email'];
	$customerphone = $row['customer_phone'];
	$customerdistrict = $row['customer_district'];
	$customeraddress = $row['customer_address'];
	$orderdate = $row['order_date'];
	$ordertime = $row['order_time'];

echo "Hi  ".$customername.", <br/> ";
echo "Thankyou for ordering from eshopNepal. ";
echo "your order details are: <br/><br/>";



}


?>

<?php
$query2="SELECT * FROM products WHERE id='$productid'";
$query3=mysqli_query($link,$query2);
$row1=mysqli_fetch_array($query3,MYSQLI_ASSOC);
$productname=$row1['product_name'];
$productprice=$row1['product_price'];
$productcode=$row1['product_code'];

?>



<table class="table table-hover" >
<tbody>
    <tr>
        <td>Name</td><td><?php echo $customername; ?></td>
    </tr>
    <tr >
    <td>email id </td><td><?php echo $customeremail; ?> </td>
    </tr>
    <tr >
    <td>Phone number </td><td><?php echo $customerphone; ?> </td>
    </tr>
    <tr>
    <td>District </td><td><?php echo $customerdistrict; ?> </td>
    </tr>
    <tr>
    <td>Address </td><td> <?php echo $customeraddress; ?></td>
    </tr>
    <tr>
    <td>Order Date </td><td><?php echo $orderdate; ?> </td>
    </tr>
    <tr>
    <td>Order Time </td><td> <?php echo $ordertime; ?></td>
    </tr>
    <tr>
    <td>Order Number </td><td><?php echo $order_id; ?> </td>
    </tr>
    <tr>
    <td>product Name </td><td><?php echo $productname; ?> </td>
    </tr>
    <tr >
    <td>product price </td><td><?php echo "Rs. ".$productprice.""; ?> </td>
    </tr>
    <tr>
    <td>product code</td><td><?php echo $productcode; ?> </td>
    </tr>
    <tr>
    <td>payment type</td><td><?php echo "cash on delivery"; ?> </td>
    </tr>
    </tbody>
</table><br/>

<p> you will receive your order within 48 hours of working hours. If you dont get your product till then please contact us.
 </p>

 <p>
Thankyou. <h3>eshopNepal</h3>
 </p>
 </div>