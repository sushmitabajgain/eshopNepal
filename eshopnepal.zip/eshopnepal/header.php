<!DOCTYPE html>
<html>
<head>
<style>
ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: rgb(171, 163, 163);
    position:fixed;
    width:100%;

}

.header li {
    float: left;
}

.header li a {
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

.header li a:hover {
    background-color: rgba(165, 156, 159, 0.55);
}
.search{
  padding-top: 10px;
}
#searchbar{
  width:400px;
  border-radius: 4px;
}


.btn-primary{
  padding-top:2px; 
  height: 30px;
  text-align: center;

}

</style>
</head>
<body>

<ul>
<div class="header" >
  <li><a href="index.php">eshopNepal</a></li>
  <li><a href="index.php">Home</a></li>
  <li> <form method='post' action='searchengine.php' class="search">
<input type="text" name="asd" id="searchbar" autocomplete="off"  class="glyphicon glyphicon-search">
<input type="submit" name="search" value="search"  class="btn btn-primary" >

 </form>
</li>
  <li><a href="contacts.php">Contact</a></li>
  <li><a href="#about">About</a></li>
  </div>
</ul>

</body>
</html>
