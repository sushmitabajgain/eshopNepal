<?php
include('adminheader.php');

?>

<link rel="stylesheet" href=../style/css/bootstrap.min.css>
<script src="../style/js/bootstrap.min.js"></script>
<?php
$db='eshop';
$link = mysqli_connect("127.0.0.1", "root", "", "$db");

?>

<div class="allprod">

<table>
<thead>
<th width="200px" >Photo </th>
<th width="200px" >product type</th>
<th width="200px" >product name</th>
<th width="200px" >product price</th>
<th width="200px" >product quantity</th>
<th width="200px" >product code</th>
<th width="200px" >product description</th>


</thead>


<?php
$query= "SELECT * FROM products";
$result=mysqli_query($link,$query);
while($row=mysqli_fetch_array($result,MYSQLI_ASSOC))
      {
           $productid=$row['id'];
          $producttype =$row['product_type'];
          $productname=$row['product_name'];
          $productprice=$row['product_price'];
          $productcode=$row['product_code'];
          $productphoto=$row['product_photo'];
          $productdesc=$row['product_description'];
           $productid=$row['id'];
           $quantity=$row['quantity'];    
               ?>
              


<table  >

<tbody>

    <tr>
        <td width="200px" > <a href="editdel.php?productid=<?php echo $productid;  ?>"> <img src=<?php echo $productphoto ?> height='200px' width='200px'/></a> </td>
    
    <td width="200px"><?php echo $producttype; ?> </td>
    
    
    
    <td width="200px"><?php echo $productname; ?> </td>
   
   <td width="200px"><?php echo "RS.  ".$productprice.""; ?> </td>
    
    
    <td width="200px"><?php echo $quantity; ?> </td>
    
    
    <td width="200px"><?php echo $productcode; ?> </td>
    <td width="200px"><?php echo $productdesc; ?> </td>
    
</tr>


                <?php
            }
?>
</div>
<style type="text/css">
	
	.allprod{
		padding-top: 80px;
	}
</style>