<?php
include('adminheader.php');

?>
<div class="addproductclass">


<link rel="stylesheet" href=../style/css/bootstrap.min.css>
<script src="../style/js/bootstrap.min.js"></script>
<?php
$db='eshop';
$link = mysqli_connect("127.0.0.1", "root", "", "$db");

?>

<form method="post" enctype="multipart/form-data" class="form-group">
product name<br/> <input type="text" name="productname" id="productname" autocomplete="off" class="form-control" value="<?PHP if(isset($_POST['productname'])) echo htmlspecialchars($_POST['productname']); ?>"><br/>

product code<br/> <input type="text" name="productcode" id="productcode" autocomplete="off" class="form-control" value="<?PHP if(isset($_POST['productcode'])) echo htmlspecialchars($_POST['productcode']); ?>"><br/>
quantity<br/> <input type="text" name="productquantity" id="productquantity" autocomplete="off" class="form-control" value="<?PHP if(isset($_POST['productquantity'])) echo htmlspecialchars($_POST['productquantity']); ?>"><br/>

price<br/> <input type="text" name="price" autocomplete="off" id="productprice" class="form-control" value="<?PHP if(isset($_POST['price'])) echo htmlspecialchars($_POST['price']); ?>"><br/>
Description<br/> <input type="text" name="description" id="productdescription" autocomplete="off" class="form-control" value="<?PHP if(isset($_POST['description'])) echo htmlspecialchars($_POST['description']); ?>"> <br/>
product photo<br/><input type="file" class="btn btn-success"  for="my-file-selector" name="user_image" accept="image/*"><br/><br/>
<p>
product category
<select name="category" class="btn btn-default dropdown-toggle" role="menu" id="selector">
  <option value="">Select...</option>
  <option value="womens_fashion">Womens fashion wears</option>
  <option value="mens_fashion">mens fashion wears</option>
  <option value="watches">watches</option>
  <option value="glasses">Glasses</option>
  <option value="mobiles">Mobile phones</option>
  <option value="computers">computers and laptops</option>
  <option value="sports">sports</option>
  <option value="shoes">shoes</option>
  <option value="musics">musics</option>
  <option value="others">others</option>
  
</select>
</p>

<input type="submit" name="submit" value="submit" class="btn btn-success">
</form>

<?php

if(isset($_POST['submit']))
{ 
  $productname=$_POST['productname'];
  $productcode=$_POST['productcode'];
  $productprice=$_POST['price'];
  $description=$_POST['description'];
  $category=$_POST['category'];
  $quantity=$_POST['productquantity'];
  
  


if($productname==''||$productcode==''||$productprice==''||$description==''||$category==''||$quantity=='')
{
  echo "please fill all the forms";

}
else 
{


$file_name=$_FILES['user_image']['name'];
  $file_type=$_FILES['user_image']['type'];
  $file_size=$_FILES['user_image']['size'];
  $file_tmp_name=$_FILES['user_image']['tmp_name'];
  $destination = "photo/".$file_name;

if($file_name)
  {
  
    move_uploaded_file($file_tmp_name, $destination);
    
 }

  $query="INSERT INTO products(product_type,product_name,product_price,product_code,product_photo,product_description,quantity) VALUES('$category','$productname','$productprice','$productcode','$destination','$description','$quantity')";
 if(mysqli_query($link,$query))
{
  
  }
else
{
  echo mysqli_error($link);
}
}
}

?>
</div>
<style type="text/css">
  .addproductclass{
    padding-top: 80px;
    height:100%;
    margin-left: 200px;
  }
  #productname{
width:500px;
  }
  #productprice{
width:500px;
  }
  #productdescription{
width:500px;
  }
  #productcode{
    width:500px;
  }
  #productquantity{
    width:500px;
  }
</style>