<link rel="stylesheet" href=../style/css/bootstrap.min.css>
<script src="../style/js/bootstrap.min.js"></script>
<link rel="stylesheet" href=../style/style.css>


<?php
include('adminheader.php');

?>
<?php
$db='eshop';
$link = mysqli_connect("127.0.0.1", "root", "", "$db");
?>


<?php
if(isset($_GET['orderer']))
{
	$order_id=$_GET['orderer'];
}

?>
<div class="ordersubmit">
<?php
$query="SELECT * FROM customer_order WHERE id='$order_id'";
$query1=mysqli_query($link,$query);
if(!$query1)
{
	echo "error";
}
else{
	$row=mysqli_fetch_array($query1,MYSQLI_ASSOC);
	$productid = $row['product_id'];
	$customername = $row['customer_name'];
	$customeremail = $row['customer_email'];
	$customerphone = $row['customer_phone'];
	$customerdistrict = $row['customer_district'];
	$customeraddress = $row['customer_address'];
	$orderdate = $row['order_date'];
	$ordertime = $row['order_time'];




}


?>

<?php
$query2="SELECT * FROM products WHERE id='$productid'";
$query3=mysqli_query($link,$query2);
$row1=mysqli_fetch_array($query3,MYSQLI_ASSOC);
$productname=$row1['product_name'];
$productprice=$row1['product_price'];
$productcode=$row1['product_code'];

?>



<table class="table table-hover" >
<tbody>
    <tr>
        <td>Name</td><td><?php echo $customername; ?></td>
    </tr>
    <tr >
    <td>email id </td><td><?php echo $customeremail; ?> </td>
    </tr>
    <tr >
    <td>Phone number </td><td><?php echo $customerphone; ?> </td>
    </tr>
    <tr>
    <td>District </td><td><?php echo $customerdistrict; ?> </td>
    </tr>
    <tr>
    <td>Address </td><td> <?php echo $customeraddress; ?></td>
    </tr>
    <tr>
    <td>Order Date </td><td><?php echo $orderdate; ?> </td>
    </tr>
    <tr>
    <td>Order Time </td><td> <?php echo $ordertime; ?></td>
    </tr>
    <tr>
    <td>Order Number </td><td><?php echo $order_id; ?> </td>
    </tr>
    <tr>
    <td>product Name </td><td><?php echo $productname; ?> </td>
    </tr>
    <tr >
    <td>product price </td><td><?php echo "Rs. ".$productprice.""; ?> </td>
    </tr>
    <tr>
    <td>product code</td><td><?php echo $productcode; ?> </td>
    </tr>
    <tr>
    <td>payment type</td><td><?php echo "cash on delivery"; ?> </td>
    </tr>
    </tbody>
</table><br/>

 </div>

 <h2>Actions</h2>
 <form method="post">
 <input type="submit" name="send_delivery" value="confirm delivery">
 <input type="submit" name="delete_delivery" value="remove delivery">
</form>
 <?php
if(isset($_POST['send_delivery']))
{
    $date=date('Y-m-d ');
    $time=date('H:i:s');
    $query="INSERT INTO sent_deliveries(product_id,customer_name,customer_email,customer_phone,customer_district,customer_address,order_date,order_time,sent_date,sent_time,product_price) VALUES('$productid','$customername','$customeremail','$customerphone','$customerdistrict','$customeraddress','$orderdate','$ordertime','$date','$time','$productprice')";
    $query1=mysqli_query($link,$query);
    if($query1)
    {
        $query = "DELETE  FROM customer_order WHERE id=$order_id";
        $query1=mysqli_query($link,$query);
        header('location:orders.php');
    }

}

 ?>

 <?php
if(isset($_POST['delete_delivery']))
{
            $query = "DELETE  FROM customer_order WHERE id=$order_id";
        $query1=mysqli_query($link,$query);
        if($query1)
        {
             header('location:orders.php');
        }
}

 ?>